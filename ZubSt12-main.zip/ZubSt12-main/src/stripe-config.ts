export const products = {
  subscription: {
    priceId: 'price_1RNPkGR2MbKWVm1FnRgmOOD7',
    name: 'Абонемент',
    description: 'Абонемент на стоматологические услуги',
    mode: 'subscription' as const,
  },
} as const;